package seleniumgluecode;

import org.openqa.selenium.WebDriver;
import BaseClass.Browser;
import PageObjectRepository.LoginPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginApplicationTest {

public static WebDriver driver;
   LoginPage login;
   
    @Given("^user is on homepage$")
    public void user_is_on_homepage() throws Throwable {  
    	driver = Browser.StartBrowser("Chrome", "your url");
        driver.manage().window().maximize();
        Thread.sleep(1000);
    }
    
    
    @When("^user navigates to Login Page$")
    public void user_navigates_to_Login_Page() throws Throwable {
    	 login = new LoginPage(driver);
   	     login.clickLogin();
    }
    
  
    @Then("^user enter username \"([^\"]*)\" and User enter password \"([^\"]*)\"$")
    public void user_enter_username_UserName_and_User_enter_password_Password(String username, String password) {
    	login = new LoginPage(driver);
  	    login.setUserName(username);
  	    login.setPassword(password);
    }
    
    
    @Then("^Close the browser$")
    public void close_the_browser() {
        driver.quit();

 }
}
